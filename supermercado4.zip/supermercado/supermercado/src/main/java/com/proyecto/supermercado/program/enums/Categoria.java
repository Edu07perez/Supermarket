package com.proyecto.supermercado.program.enums;

public enum Categoria {
    ALIMENTACION, DROGUERIA, HIGIENE, MASCOTAS
}
