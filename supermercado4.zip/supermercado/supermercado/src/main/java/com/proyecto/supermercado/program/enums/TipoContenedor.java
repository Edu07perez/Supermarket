package com.proyecto.supermercado.program.enums;

public enum TipoContenedor {

    BOLSA, CAJA
}
