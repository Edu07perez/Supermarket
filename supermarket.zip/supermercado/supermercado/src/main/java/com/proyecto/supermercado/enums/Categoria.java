package com.proyecto.supermercado.enums;

public enum Categoria {
    ALIMENTACION, DROGUERIA, HIGIENE, MASCOTAS
}
