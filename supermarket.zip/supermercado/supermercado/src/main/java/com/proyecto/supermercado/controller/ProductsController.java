package com.proyecto.supermercado.controller;

import com.proyecto.supermercado.entity.Empleado;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class ProductsController {
    @GetMapping("/pages/Products")
    public String productsController() {
        return "pages/Products";
    }

    @GetMapping("/pages/Products/new")
    public String createProductsForm(Model model){
        //create empleado object to hold student form data
        Empleado empleado = new Empleado();
        model.addAttribute("empleado", empleado);
        return "pages/create_empleado";
    }
}
