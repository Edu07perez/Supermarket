package com.proyecto.supermercado;

import com.proyecto.supermercado.contenedores.Contenedor;
import com.proyecto.supermercado.enums.Categoria;

public interface IProducto {
    String getReferencia();

    double getPrecio();

    float getPeso();

    boolean tengoEspacio(IContenedor contenedor);

    int getVolumen();

    Categoria getCategoria();

    boolean esCompatible(IProducto p);

    void meter(Contenedor contenedor);
}
