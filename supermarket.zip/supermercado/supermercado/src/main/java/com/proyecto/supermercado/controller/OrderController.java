package com.proyecto.supermercado.controller;

import com.proyecto.supermercado.entity.Empleado;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class OrderController {
    @GetMapping("/pages/Orders")
    public String orderController(){
        return "pages/Orders";
    }

    @GetMapping("/pages/Orders/new")
    public String createOrdersForm(Model model){
        //create empleado object to hold student form data
        Empleado empleado = new Empleado();
        model.addAttribute("empleado", empleado);
        return "pages/Orders";
    }
}
