package com.proyecto.supermercado.service.impl;

import com.proyecto.supermercado.entity.Empleado;
import com.proyecto.supermercado.repository.EmpleadoRepository;
import com.proyecto.supermercado.service.EmpleadoService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EmpleadoServiceImpl implements EmpleadoService {

    private final EmpleadoRepository empleadoRepository;


    public EmpleadoServiceImpl(EmpleadoRepository empleadoRepository){
        super();
        this.empleadoRepository = empleadoRepository;
    }


    @Override
    public List<Empleado> getAllEmpleados() {
        return empleadoRepository.findAll();
    }

    @Override
    public Empleado saveEmpleado(Empleado empleado) {
        return empleadoRepository.save(empleado);
    }

    @Override
    public Empleado getEmpleadoById(Long id) {
        return empleadoRepository.findById(id).get();
    }

    @Override
    public Empleado updateEmpleado(Empleado empleado) {
        return empleadoRepository.save(empleado);
    }

    @Override
    public void deleteEmpleadoById(Long id) {
        empleadoRepository.deleteById(id);
    }
}
