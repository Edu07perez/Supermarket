package com.proyecto.supermercado.service;

import com.proyecto.supermercado.entity.Empleado;

import java.util.List;

public interface EmpleadoService {

    List<Empleado> getAllEmpleados();
    Empleado saveEmpleado(Empleado empleado);
    Empleado getEmpleadoById(Long id);
    Empleado updateEmpleado(Empleado empleado);
    void deleteEmpleadoById(Long id);
}
