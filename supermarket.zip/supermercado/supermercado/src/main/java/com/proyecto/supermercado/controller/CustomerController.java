package com.proyecto.supermercado.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class CustomerController {

    @GetMapping("/pages/Customers")
    public String customers() {
    return "pages/Customers";
    }
}
