package com.proyecto.supermercado;

public class Pedido {
}
