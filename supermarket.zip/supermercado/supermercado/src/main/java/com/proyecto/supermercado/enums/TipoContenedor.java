package com.proyecto.supermercado.enums;

public enum TipoContenedor {

    BOLSA, CAJA
}
